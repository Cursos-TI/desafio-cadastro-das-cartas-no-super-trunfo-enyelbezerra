#areaine _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <fstream>
#include <iomanip>
#include "Gerador-Prototipos.h"

using namespace std;

void tracos(int quant) { //  funcao para linhas
	for (int i = 0; i < quant; i++) {
		cout << "-";
	}
	cout << endl;
}

int verificador(const char * file, carta Cards[]) { // verifica a quantidade de cartas e retorna a quant cartas
	int QuantCards = 0;
	int i = 0;

	carta newCards;
	ifstream fin;
	
	fin.open(file, ios_base::in |ios_base::binary);
	while (fin.read((char*) &newCards, sizeof(carta))) {
		if (QuantCards > 20) { // caso tenha mais de 20 cartas fechara o arquivo
			fin.close();
			return QuantCards;
		}
		Cards[i] = newCards; 
		QuantCards++;  // cards na posicao do indice recebera newCards a cada laco de repeticao
		i++;
	}
	fin.close();
	return QuantCards;  // retornar�  quantidade de cartas
}

int cadastrar(carta paises, carta * cards, int QuantCards) {
	if (QuantCards == 0) { // far� o cadastro conforme a quantidade de cartas
		cards[0] = paises;
		QuantCards++;
	}
	else {
		cards[QuantCards] = paises;
		QuantCards++;
	}
	return QuantCards;
}

void lista(carta * cartas, int QuantCards) {
	cout << "\nCartas no baralho: " << endl;
	tracos(10);
	
	for (int i = 0; i < QuantCards; i++) { 
		cout << i + 1 << "# " << cartas[i].nome << " " << cartas[i].pop << " " << cartas[i].area << " ";
		cout << cartas[i].pib << " " << cartas[i].pontostur << endl;
	}
}
void alterar(carta * paisesCards, int NumCard) {
	// altera conforme a opcao desejada no main
	cout << "Alterando carta ";
	cout << paisesCards[NumCard - 1].nome << endl;
	cin.get();
	cout << "Nome: ";
	cin.getline(paisesCards[NumCard - 1].nome, 30);
	cout << "Popula��o: ";
	cin >> paisesCards[NumCard - 1].pop;
	cout << "�rea: ";
	cin >> paisesCards[NumCard - 1].area;
	cout << "PIB: ";
	cin >> paisesCards[NumCard - 1].pib;
	cout << "pPontos-Tur�sticos: ";
	cin >> paisesCards[NumCard - 1].pontostur;
}

int excluir(carta * paisesCards, int opcao, int QuantCards) {	
	int cont = 0;
	carta apagada;
	
	for (int i = (opcao - 1); i < QuantCards; i++) { // laco come�ara com a opcao desejada e removera ele
		if (cont == 0) { 
			strcpy(apagada.nome, paisesCards[i].nome); // mostrar a carta que foi deletada
			cont++;
		}
		paisesCards[i] = paisesCards[i + 1];  // carta selecionada e sobrescrita com a proxima 
	}
	cout << "Carta " << apagada.nome << " foi excluida do baralho.\n";
	QuantCards--; // diminui a quantidade de cartas
	return QuantCards; // atualiza quantidade de cartas
}

void saveGame(const char * fileBin, carta * paisesCards, int QuantCards) {
	ofstream fout	;
	ifstream fin;

	carta * NewCards = new carta[QuantCards];
	for (int i = 0; i < QuantCards; i++) { // passa as informacoes para vetor dinamico 
		NewCards[i] = paisesCards[i];
	}
	fout.open(fileBin, ios_base::out | ios_base::app |ios_base::binary);
	
	for (int i = 0; i < QuantCards; i++) { // escrita no arquivo binario
		fout.write((char*) &NewCards[i], sizeof(carta));
	}
	fout.close();
	delete[] NewCards;
}

int IMPORTAR(const char * fileTxt, carta cards[], int QuantCards) {
	ifstream fin;

	fin.open(fileTxt, ios_base::in); // abertura do arquivo
	carta x;
	 
	int cont = 0;
	int i = QuantCards - 1;

	cout << endl;
	while (!fin.eof(), fin >> x.nome) { // ha o transporte das cartas do arquivo para o vetor de cartas
		fin >> x.pop >> x.area >> x.pib >> x.pontostur;
		// transporte para cada laco
		strcpy(cards[++i].nome, x.nome);
		cards[i].pop = x.pop;
		cards[i].area = x.area;
		cards[i].pib = x.pib;
		cards[i].pontostur = x.pontostur;

		cout << cards[i].nome << " " << cards[i].pop << " " << cards[i].area << " ";
		cout << cards[i].pib << " " << cards[i].pontostur << endl;
		cont++;
	}
	fin.close();
	QuantCards += cont; 
	return QuantCards;
}

#include <iostream>
#include <fstream>
#include "Gerador-Prototipos.h"

const int TAM = 32;
using namespace std;

int main() {
	int QuantCards = 0;
	carta cartas[TAM]; // Vetor Est�tico
	
	bool fechar = false;
	QuantCards = verificador("paises.dat", cartas); // o  vetor cartas ir� receber os dados do binario

	do {
		cout << "Gerador De Cartas\n";
		tracos(10);
		cout << "(C)adastrar\n"
			"(I)mportar\n"
			"(A)lterar\n"
			"(E)xcluir\n"
			"(L)istar\n"
			"(S)air\n";
		cout << "Escolha uma opcao: [ ]\b\b";
		char opcao; cin >> opcao;
		opcao = toupper(opcao);
		switch (opcao)
		{
		case 'C':
			cout << "Cadastrar Carta\n";
			tracos(10);
			cin.ignore();

			carta paises;
			cout << "Nome: ";
			cin.getline(paises.nome, 30)	;
			cout << "Popula��o: ";
			cin >> paises.pop;
			cout << "�rea: ";
			cin >> paises.area;
			cout << "PIB: ";
			cin >> paises.pib;
			cout << "Pontos-Tur�sticos: ";
			cin >> paises.pontostur;
			QuantCards = cadastrar(paises, cartas, QuantCards); // atualiza as Quantidade De Cartas
			break;
		case 'A':
		cout << "Atualizar Cartas\n";
		tracos(10);
		
		for (int i = 0; i < QuantCards; i++) {
		cout << i + 1 << ") " << cartas[i].nome << endl;
		}
		cout << "Digite o numero da carta: [ ]\b\b";
		int opcao; cin >> opcao;
		
		//VERIFICA��O
		if ((opcao > QuantCards) || (opcao < 1)) {
			break;
		}
		else {
			alterar(cartas, opcao);
			break;
		}
		
		case 'E':
			cout << "Excluir Carta\n";
			tracos(10);
			for (int i = 0; i < QuantCards; i++) {
				cout << i + 1 << ") " << cartas[i].nome << endl;
			}
			cout << "Digite o numero da carta [ ]\b\b";
			int op; cin >> op;
			if ((op > QuantCards) | (op < 1)) {
				break;
			}
			else {
				QuantCards = excluir(cartas, op, QuantCards);
				break;
			}
		case 'L': 
			lista(cartas, QuantCards);
			break;
		case 'I':
			cout << "Importar Cartas\n";
			tracos(10);

			cout << "Importando: ";
			QuantCards = IMPORTAR("maiscartas.txt", cartas, QuantCards);
			break;
		case 'S':
			fechar = true;
			break;
		areaault:
			cout << "Opcao Invalida!\n";
			break;
		}
	} while (fechar != true);
	
	saveGame("paises.dat", cartas, QuantCards);
	system("pause");
	return 0;
}

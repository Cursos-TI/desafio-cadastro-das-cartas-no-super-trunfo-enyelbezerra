struct carta { // caracteriristicas da carta
	char nome[30];
	unsigned pop, area, pib, pontostur;
};
void tracos(int x);

//fun��es 
int verificador(const char * file, carta Cards[]);
int cadastrar(carta paises, carta * cards, int QuantCards);
void lista(carta * cartas, int QuantCards);
void alterar(carta * paisesCards, int NumCard);
int excluir(carta * paisesCards, int opcao, int QuantCards);
int IMPORTAR(const char * fileTxt, carta cards[], int QuantCards);
void saveGame(const char * fileBin, carta * paisesCards, int QuantCards);

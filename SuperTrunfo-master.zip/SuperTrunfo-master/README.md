# SuperTrunfo
O Super Trunfo é um jogo de baralho em que cada carta tem uma um certo número de características.
Os mais jogadores se enfrentam escolhendo características de uma carta e a característica que tiver o maior valor numérico ganha a rodada, ficando com as cartas dos outros jogadores. Quem conseguir ficar com o maior número de pontos vence.

Para o trabalho, o jogo será levemente adaptado para simplificar a sua programação:

Existem apenas 2 competidores

1. Cada competidor recebe 4 cartas aleatórias de um conjunto do baralho
2. Competidor 1 e 2 se alternam na escolha de uma caracteristica de cada carta por rodada
3. A cada rodada um novo par de cartas é selecionado
4. Cada vitória conta 2 pontos, empates contam 1 ponto
5. Ao final de 4 rodadas, o competidor que tiver mais pontos ganha

No exercício temos o jogo e o gerador de cartas
* Gerador de Cartas
* Jogo

#include <iostream>
#include <fstream>
#include <random>
#include "Game.h"

using namespace std;

int verificador(const char * file, carta Cards[]) {
	int QuantCards = 0;
	int i = 0;

	carta newCards;
	ifstream fin;
	fin.open(file, ios_base::in | ios_base::binary);

	while (fin.read((char*) &newCards, sizeof(carta))) { // ler
		if (QuantCards > 20) { // se tiver mais de 20 cartas fecha o arquivo
			fin.close();
			break;
		}
		Cards[i] = newCards;
		QuantCards++;  // cards na posicao do indice receber� newCards a cada laco de repeticao
		i++;
	}
	fin.close();  // retornar�  quantidade de cartas do baralho
	return QuantCards;
}

void tracos(int quant) { //  funcao para linhas
	for (int i = 0; i < quant; i++) {
		cout << "-";
	}
	cout << endl;
}

unsigned short menu() { // menu retorna a opcao
	cout << "1. Popula��o\n"
		<< "2. �rea\n"
		<< "3. PIB\n"
		<< "4. Pontos-Tur�sticos\n";
	cout << "Escolha um atributo [ ]\b\b";
	unsigned short opcao; cin >> opcao;
	return opcao;
}

int aleatorio(int sizeX) { // gera um numero 
	random_device rd;
	mt19937 mt(rd());
	uniform_int_distribution<> dist(0, sizeX);

	return dist(mt);
}
